function Exit() {
    deleteCookie('uuid');

    reslide('login.html')
}