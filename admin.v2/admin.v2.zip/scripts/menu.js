document.querySelector('.menu').addEventListener('click' , (e) => {
    document.querySelector('.hide__menu').classList.toggle('hide')
})