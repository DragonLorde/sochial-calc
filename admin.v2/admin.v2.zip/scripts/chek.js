if(!getCookie('uuid')) {
    reslide('login.html')
}